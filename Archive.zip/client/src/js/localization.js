var localization = {
  show: 'Mostrar',
  learnMore: 'Más información',
  directions: 'Cómo llegar',
  title: 'Patrimonio de Medellín',
  back: 'Regresar a los Resultados',
  newSearch: 'Nueva Búsqueda'
}

module.exports = localization;