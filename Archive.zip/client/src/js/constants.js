'use strict';

var Constants = {
  icons: {
    'sculpture': 'images/icon-statue-25.png',
    'Escultura': 'images/icon-statue-25.png',
    'archSite': 'images/icon-dig-25.png',
    'Hallazgo Arqueológico': 'images/icon-dig-25.png'
  },
  logo: 'images/logo.png',
  imageSrcRoot: 'images/heritageItems/'
};

module.exports = Constants;